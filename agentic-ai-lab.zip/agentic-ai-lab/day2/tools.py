import datetime

def calculator(expression):
    """Performs mathematical calculations."""
    try:
        # Removing any non-math words if they slipped in
        clean_expr = expression.replace("calculate", "").strip()
        return f"Result: {eval(clean_expr)}"
    except Exception as e:
        return f"Error in calculation: {e}"

def get_weather(city):
    """Mock weather tool."""
    # In a real scenario, this would call an API
    return f"The weather in {city} is currently 22°C and sunny."

def summarizer(text):
    """Simple logic to 'summarize' by taking the first sentence."""
    sentences = text.split('.')
    if len(sentences) > 1:
        return f"Summary: {sentences[0]}..."
    return f"Summary: {text}"